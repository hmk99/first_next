"use client";
import { useBasket } from "../BasketContext";
import { useState } from "react";

export default function BasketPage() {
  const path = "https://gnmc-dz.com/ecomm/";

  const { basket, removeFromBasket } = useBasket();
  const [name, setName] = useState("");
  const [wilaya, setWilaya] = useState("");
  // Track quantities for each product (by index)
  const [quantities, setQuantities] = useState(basket.map(() => 1));
  console.log(basket);

  // Update quantity for a product
  const handleQuantityChange = (idx, value) => {
    const newQuantities = [...quantities];
    newQuantities[idx] = Math.max(1, Number(value));
    setQuantities(newQuantities);
  };

  // Calculate totals
  const totalItems = quantities.reduce((sum, q) => sum + q, 0);
  const totalPrice = basket.reduce(
    (sum, item, idx) => sum + Number(item.price) * (quantities[idx] || 1),
    0
  );

  console.log(basket);

  return (
    <div className="p-8 min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-100">
      <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-2xl p-8">
        <h1 className="text-4xl font-extrabold text-center text-blue-700 mb-8 tracking-tight drop-shadow-lg">
          🧺 Your Basket
        </h1>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          <div>
            <label className="block text-lg font-semibold text-blue-900 mb-2">
              Name
            </label>
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-blue-900 font-medium bg-blue-50"
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-lg font-semibold text-blue-900 mb-2">
              Wilaya
            </label>
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-blue-900 font-medium bg-blue-50"
              placeholder="Your Wilaya"
              value={wilaya}
              onChange={(e) => setWilaya(e.target.value)}
            />
          </div>
        </form>
        {basket.length === 0 ? (
          <p className="text-center text-gray-500 text-lg">
            Your basket is empty.
          </p>
        ) : (
          <>
            <ul className="space-y-6 mb-10">
              {basket.map((item, idx) => (
                <li
                  key={idx}
                  className="p-6 bg-gradient-to-r from-blue-100 via-white to-purple-100 rounded-2xl shadow flex flex-col md:flex-row justify-between items-center gap-4 border border-blue-200 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    {item.image && (
                      <img
                        loading="lazy"
                        src={item.image}
                        alt={item.gamme}
                        className="w-20 h-20 object-cover rounded-xl border-2 border-blue-200 shadow"
                      />
                    )}
                    <div>
                      <div className="font-bold text-xl text-[#252525] mb-1">
                        {item.gamme}
                      </div>
                      {/* <div className="text-gray-600 mb-1">{item.dsc}</div> */}
                      <div className="text-blue-700 font-bold text-lg">
                        {item.price} DA
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-center gap-2 w-full md:w-auto">
                    <label className="text-sm font-semibold text-blue-900">
                      Quantity
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={quantities[idx] || 1}
                      onChange={(e) =>
                        handleQuantityChange(idx, e.target.value)
                      }
                      className="w-20 px-3 py-2 rounded-lg border-2 border-blue-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-blue-900 font-bold bg-blue-50 text-center"
                    />
                  </div>
                  <button
                    className="text-red-600 hover:bg-red-100 hover:text-red-800 font-bold px-4 py-2 rounded-lg transition-all duration-200 border border-red-200 shadow-sm"
                    onClick={() => removeFromBasket(idx)}
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
            {/* Order Recap */}
            <div className="bg-gradient-to-r from-blue-200 via-white to-purple-200 rounded-2xl shadow-lg p-8 mt-8 border-2 border-blue-100">
              <h2 className="text-2xl font-bold text-blue-800 mb-4 text-center">
                Order Recap
              </h2>
              <div className="flex flex-col gap-2 text-lg text-blue-900 mb-4">
                <div>
                  <span className="font-semibold">Name:</span>{" "}
                  {name || (
                    <span className="text-gray-400">(not provided)</span>
                  )}
                </div>
                <div>
                  <span className="font-semibold">Wilaya:</span>{" "}
                  {wilaya || (
                    <span className="text-gray-400">(not provided)</span>
                  )}
                </div>
                <div>
                  <span className="font-semibold">Total Items:</span>{" "}
                  {totalItems}
                </div>
                <div>
                  <span className="font-semibold">Total Price:</span>{" "}
                  {totalPrice.toLocaleString()} DA
                </div>
              </div>
              <div className="border-t border-blue-300 pt-4">
                <h3 className="font-semibold text-blue-700 mb-2">Products:</h3>
                <ul className="list-disc list-inside text-blue-900">
                  {basket.map((item, idx) => (
                    <li key={idx}>
                      {quantities[idx] || 1} x{" "}
                      <span className="font-semibold">{item.gamme}</span> (
                      {item.price} DA each)
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
