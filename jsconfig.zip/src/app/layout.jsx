import { Montserrat } from "next/font/google";
import "./globals.css";
import { BasketProvider } from "./BasketContext";
import NavBar from "./NavBar";
// import PageTransitionWrapper from "./PageTransitionWrapper";

// --- SEO: Default metadata for the app ---
export const metadata = {
  title: {
    default: "My Next App",
    template: "%s | My Next App",
  },
  description:
    "A modern Next.js app for movies, products, and more. Discover, shop, and enjoy!",
  openGraph: {
    title: "My Next App",
    description:
      "A modern Next.js app for movies, products, and more. Discover, shop, and enjoy!",
    url: "https://yourdomain.com/",
    siteName: "My Next App",
    images: [
      {
        url: "/logo.jpg",
        width: 800,
        height: 600,
        alt: "My Next App Logo",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  metadataBase: new URL("https://yourdomain.com"),
  alternates: {
    canonical: "/",
  },
};
// --- End SEO ---

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  weight: ["400", "700"],
  display: "swap",
});

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={montserrat.className}>
        <BasketProvider>
          <NavBar />
          <main className="mt-[10vh] min-h-[80vh]">{children}</main>
        </BasketProvider>
      </body>
    </html>
  );
}
